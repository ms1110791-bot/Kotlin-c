package com.example.settingshub

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var overlayStatus: TextView
    private lateinit var notifStatus: TextView
    private lateinit var floatButton: Button

    private val notifLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { refresh() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun hasOverlay() = Settings.canDrawOverlays(this)

    private fun hasNotif() =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED

    private fun refresh() {
        setStatus(overlayStatus, hasOverlay())
        setStatus(notifStatus, hasNotif())
        floatButton.text = if (FloatingService.running) "⏹  फ्लोटिंग विंडो बंद करो" else "🚀  फ्लोटिंग विंडो शुरू करो"
    }

    private fun setStatus(tv: TextView, ok: Boolean) {
        tv.text = if (ok) "✅ मिल गई" else "❌ चाहिए"
        tv.setTextColor(if (ok) Ui.OK else Ui.BAD)
    }

    private fun requestOverlay() {
        startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        )
    }

    private fun requestNotif() {
        if (Build.VERSION.SDK_INT >= 33) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun toggleFloating() {
        if (FloatingService.running) {
            stopService(Intent(this, FloatingService::class.java))
            FloatingService.running = false
            refresh()
            return
        }
        if (!hasOverlay()) {
            Toast.makeText(this, "पहले Overlay परमिशन दो", Toast.LENGTH_SHORT).show()
            requestOverlay()
            return
        }
        if (!hasNotif()) requestNotif()
        ContextCompat.startForegroundService(this, Intent(this, FloatingService::class.java))
        FloatingService.running = true
        refresh()
        moveTaskToBack(true)
    }

    private fun permissionRow(title: String, status: TextView, buttonText: String, onClick: () -> Unit): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(6), 0, dp(6))
            val texts = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                addView(Ui.label(this@MainActivity, title, 14f, Ui.TEXT, true))
                addView(status)
            }
            addView(texts, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(Button(this@MainActivity).apply {
                text = buttonText
                isAllCaps = false
                setOnClickListener { onClick() }
            })
        }

    private fun buildUi(): ScrollView {
        overlayStatus = Ui.label(this, "", 12f, Ui.SUB)
        notifStatus = Ui.label(this, "", 12f, Ui.SUB)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(24), dp(14), dp(24))
        }

        page.addView(Ui.label(this, "⚙️ Settings Hub", 26f, Ui.TEXT, true))
        page.addView(Ui.label(this, "कोई भी सेटिंग एक टैप में खोलो — ऐप के अंदर भी और फ्लोटिंग विंडो से भी", 13f, Ui.SUB).apply {
            setPadding(0, dp(4), 0, dp(12))
        })

        val permCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.rounded(Ui.CARD, dp(18).toFloat())
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        permCard.addView(Ui.label(this, "🔑 परमिशन", 15f, Ui.TEXT, true))
        permCard.addView(permissionRow("Overlay (दूसरे ऐप्स के ऊपर दिखाना)", overlayStatus, "दो") { requestOverlay() })
        if (Build.VERSION.SDK_INT >= 33) {
            permCard.addView(permissionRow("Notifications", notifStatus, "दो") { requestNotif() })
        } else {
            notifStatus.text = ""
        }
        page.addView(permCard)

        floatButton = Button(this).apply {
            isAllCaps = false
            textSize = 16f
            setTextColor(Ui.TEXT)
            background = Ui.rounded(Ui.ACCENT, dp(16).toFloat())
            setOnClickListener { toggleFloating() }
        }
        page.addView(
            floatButton,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(56)
            ).apply { setMargins(0, dp(14), 0, dp(4)) }
        )

        Catalog.categories.forEach { cat ->
            page.addView(Ui.sectionTitle(this, cat.title))
            page.addView(Ui.grid(this, cat.items, 3) { item -> Launcher.open(this, item) })
        }

        page.addView(Ui.label(this, "💡 टिप: ⚙️ बबल को drag करके कहीं भी रखो, टैप करने पर पैनल खुलेगा।", 12f, Ui.SUB).apply {
            setPadding(dp(4), dp(18), dp(4), 0)
        })

        return ScrollView(this).apply {
            setBackgroundColor(Ui.BG)
            addView(page)
        }
    }
}
