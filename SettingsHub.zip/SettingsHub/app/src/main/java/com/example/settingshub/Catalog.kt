package com.example.settingshub

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings

/** एक सेटिंग का शॉर्टकट: आइकन (emoji), नाम, और उसे खोलने वाला Intent। */
data class SettingItem(
    val emoji: String,
    val label: String,
    val intentBuilder: (Context) -> Intent
)

data class Category(val title: String, val items: List<SettingItem>)

object Catalog {

    private fun simple(emoji: String, label: String, action: String) =
        SettingItem(emoji, label) { Intent(action) }

    private fun appDetails(ctx: Context) =
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))

    val categories: List<Category> = listOf(
        Category(
            "📡 कनेक्शन",
            listOf(
                simple("📶", "Wi-Fi", Settings.ACTION_WIFI_SETTINGS),
                simple("🔵", "Bluetooth", Settings.ACTION_BLUETOOTH_SETTINGS),
                simple("✈️", "Airplane मोड", Settings.ACTION_AIRPLANE_MODE_SETTINGS),
                simple("📱", "मोबाइल डेटा", Settings.ACTION_DATA_ROAMING_SETTINGS),
                simple("📲", "NFC", Settings.ACTION_NFC_SETTINGS),
                simple("🔐", "VPN", Settings.ACTION_VPN_SETTINGS),
                simple("📺", "Cast", Settings.ACTION_CAST_SETTINGS),
                simple("🌐", "वायरलेस", Settings.ACTION_WIRELESS_SETTINGS)
            )
        ),
        Category(
            "📱 डिवाइस",
            listOf(
                simple("🖥️", "डिस्प्ले", Settings.ACTION_DISPLAY_SETTINGS),
                simple("🔊", "साउंड", Settings.ACTION_SOUND_SETTINGS),
                simple("🔋", "बैटरी सेवर", Settings.ACTION_BATTERY_SAVER_SETTINGS),
                simple("💾", "स्टोरेज", Settings.ACTION_INTERNAL_STORAGE_SETTINGS),
                simple("🖨️", "प्रिंट", Settings.ACTION_PRINT_SETTINGS)
            )
        ),
        Category(
            "🧩 ऐप्स और परमिशन",
            listOf(
                simple("📦", "सभी ऐप्स", Settings.ACTION_MANAGE_ALL_APPLICATIONS_SETTINGS),
                simple("⭐", "डिफ़ॉल्ट ऐप्स", Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS),
                simple("🔔", "Notification एक्सेस", Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS),
                simple("📊", "Usage एक्सेस", Settings.ACTION_USAGE_ACCESS_SETTINGS),
                simple("🪟", "Overlay परमिशन", Settings.ACTION_MANAGE_OVERLAY_PERMISSION),
                simple("⚡", "बैटरी ऑप्टिमाइज़", Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS),
                SettingItem("ℹ️", "इस ऐप की डिटेल") { ctx -> appDetails(ctx) },
                SettingItem("🔕", "इस ऐप के Notifications") { ctx ->
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                            .putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
                    } else {
                        appDetails(ctx)
                    }
                }
            )
        ),
        Category(
            "🛠️ सिस्टम",
            listOf(
                simple("♿", "Accessibility", Settings.ACTION_ACCESSIBILITY_SETTINGS),
                simple("🕒", "तारीख और समय", Settings.ACTION_DATE_SETTINGS),
                simple("🌍", "भाषा", Settings.ACTION_LOCALE_SETTINGS),
                simple("⌨️", "कीबोर्ड", Settings.ACTION_INPUT_METHOD_SETTINGS),
                simple("📍", "लोकेशन", Settings.ACTION_LOCATION_SOURCE_SETTINGS),
                simple("🛡️", "सिक्योरिटी", Settings.ACTION_SECURITY_SETTINGS),
                simple("🔏", "प्राइवेसी", Settings.ACTION_PRIVACY_SETTINGS),
                simple("👨‍💻", "Developer ऑप्शन", Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS),
                simple("🔄", "Sync", Settings.ACTION_SYNC_SETTINGS),
                simple("📋", "फोन के बारे में", Settings.ACTION_DEVICE_INFO_SETTINGS),
                simple("⚙️", "सारी सेटिंग्स", Settings.ACTION_SETTINGS)
            )
        )
    )
}
