package com.example.settingshub

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/** थीम के रंग और छोटे UI helper (पूरा UI कोड से बनता है, XML की ज़रूरत नहीं)। */
object Ui {
    val BG: Int = Color.parseColor("#0F1220")
    val CARD: Int = Color.parseColor("#1B1F33")
    val TILE: Int = Color.parseColor("#252A45")
    val ACCENT: Int = Color.parseColor("#7C5CFF")
    val TEXT: Int = Color.parseColor("#FFFFFF")
    val SUB: Int = Color.parseColor("#9AA3C0")
    val OK: Int = Color.parseColor("#3DDC97")
    val BAD: Int = Color.parseColor("#FF6B6B")

    fun rounded(color: Int, radiusPx: Float): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radiusPx
        }

    fun label(ctx: Context, s: String, sp: Float, color: Int, bold: Boolean = false): TextView =
        TextView(ctx).apply {
            text = s
            textSize = sp
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

    fun sectionTitle(ctx: Context, s: String): TextView =
        label(ctx, s, 15f, TEXT, true).apply {
            setPadding(ctx.dp(4), ctx.dp(14), ctx.dp(4), ctx.dp(4))
        }

    private fun tile(ctx: Context, item: SettingItem, onClick: (SettingItem) -> Unit): View =
        LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            minimumHeight = ctx.dp(84)
            setPadding(ctx.dp(6), ctx.dp(8), ctx.dp(6), ctx.dp(8))
            background = rounded(TILE, ctx.dp(14).toFloat())
            addView(TextView(ctx).apply {
                text = item.emoji
                textSize = 26f
                gravity = Gravity.CENTER
            })
            addView(label(ctx, item.label, 11f, TEXT).apply {
                gravity = Gravity.CENTER
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
            })
            setOnClickListener { onClick(item) }
        }

    /** items को cols कॉलम वाले ग्रिड में दिखाता है। */
    fun grid(ctx: Context, items: List<SettingItem>, cols: Int, onClick: (SettingItem) -> Unit): LinearLayout {
        val m = ctx.dp(4)
        val column = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        items.chunked(cols).forEach { rowItems ->
            val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
            rowItems.forEach { item ->
                val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                lp.setMargins(m, m, m, m)
                row.addView(tile(ctx, item, onClick), lp)
            }
            repeat(cols - rowItems.size) {
                val lp = LinearLayout.LayoutParams(0, 1, 1f)
                lp.setMargins(m, m, m, m)
                row.addView(View(ctx), lp)
            }
            column.addView(
                row,
                LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            )
        }
        return column
    }
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

/** सेटिंग खोलता है; अगर इस फोन पर नहीं मिली तो मुख्य Settings खोल देता है (crash नहीं होता)। */
object Launcher {
    fun open(ctx: Context, item: SettingItem) {
        try {
            val intent = item.intentBuilder(ctx).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)
        } catch (e: Exception) {
            try {
                ctx.startActivity(
                    Intent(android.provider.Settings.ACTION_SETTINGS)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                Toast.makeText(ctx, "ये सेटिंग इस फोन पर नहीं मिली, मुख्य Settings खोली", Toast.LENGTH_SHORT).show()
            } catch (e2: Exception) {
                Toast.makeText(ctx, "Settings नहीं खुल पाई", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
