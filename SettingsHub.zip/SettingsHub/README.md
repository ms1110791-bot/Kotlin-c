# Settings Hub (Kotlin सीखने वाला प्रोजेक्ट)

फ्लोटिंग ⚙️ बबल वाला Android ऐप — टैप करो, पैनल खुलता है, किसी भी आइकन पर टैप करो तो उस सेटिंग का पेज खुल जाता है।

## कैसे चलाएँ
1. Android Studio में **Open** → यह फोल्डर चुनो (JDK 17, Gradle 8.2+ चाहिए)।
2. Sync होने दो → Run।
3. ऐप खोलो → **Overlay परमिशन** दो → **फ्लोटिंग विंडो शुरू करो**।

(GitHub Actions से बनाना हो तो अपना workflow/YML खुद जोड़ना; Gradle wrapper Android Studio पहली बार Sync पर बना देता है।)

## फाइलें और वे क्या करती हैं
| फाइल | काम |
|---|---|
| `Catalog.kt` | सारी सेटिंग्स की लिस्ट (emoji, नाम, Intent)। **नई सेटिंग जोड़ने के लिए बस यहाँ एक लाइन जोड़ो।** |
| `Ui.kt` | रंग/थीम, ग्रिड और टाइल बनाने वाले helper, और `Launcher.open()` जो crash के बिना सेटिंग खोलता है |
| `MainActivity.kt` | मुख्य स्क्रीन: परमिशन कार्ड, फ्लोटिंग ON/OFF बटन, सारे आइकन |
| `FloatingService.kt` | फ्लोटिंग बबल (drag होता है) और उसका पैनल, WindowManager से बनता है |
| `AndroidManifest.xml` | परमिशन्स और service की घोषणा |

## सीखने के लिए आइडिया
- `Catalog.kt` में नई सेटिंग जोड़ो, जैसे `simple("🎧", "हेडफ़ोन", Settings.ACTION_SOUND_SETTINGS)`
- `Ui.kt` में रंग बदलकर थीम बदलो
- पैनल में `cols` 3 से 4 करके देखो
